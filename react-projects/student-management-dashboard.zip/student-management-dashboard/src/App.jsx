import { useState } from 'react';
import {
  GraduationCap,
  Users,
  CheckCircle2,
  XCircle,
  Mail,
  BookOpen,
  Calendar,
  ArrowRight,
  Search,
} from 'lucide-react';

const initialStudents = [
  {
    id: 1,
    name: 'Rahul Sharma',
    course: 'React',
    age: 21,
    status: 'Active',
    email: 'rahul.sharma@example.com',
  },
  {
    id: 2,
    name: 'Aman Kumar',
    course: 'Node.js',
    age: 22,
    status: 'Inactive',
    email: 'aman.kumar@example.com',
  },
  {
    id: 3,
    name: 'Priya Singh',
    course: 'React',
    age: 20,
    status: 'Active',
    email: 'priya.singh@example.com',
  },
  {
    id: 4,
    name: 'Sahil Khan',
    course: 'MERN Stack',
    age: 23,
    status: 'Active',
    email: 'sahil.khan@example.com',
  },
];

function App() {
  const [students] = useState(initialStudents);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredStudents = students.filter((student) =>
    `${student.name} ${student.course}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase())
  );

  const activeStudents = students.filter(
    (student) => student.status === 'Active'
  ).length;

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="brand-icon">
            <GraduationCap size={25} />
          </div>
          <div>
            <h1>StudentHub</h1>
            <span>Management Portal</span>
          </div>
        </div>

        <div className="topbar-badge">
          <span className="online-dot"></span>
          Dashboard
        </div>
      </header>

      <main className="container">
        <section className="hero">
          <div>
            <p className="eyebrow">OVERVIEW</p>
            <h2>Student Management Dashboard</h2>
            <p className="hero-text">
              Manage your students and keep track of their learning journey.
            </p>
          </div>

          <div className="hero-icon">
            <Users size={42} />
          </div>
        </section>

        <section className="stats">
          <div className="stat-card">
            <div className="stat-icon purple">
              <Users size={22} />
            </div>
            <div>
              <span>Total Students</span>
              <strong>{students.length}</strong>
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-icon green">
              <CheckCircle2 size={22} />
            </div>
            <div>
              <span>Active Students</span>
              <strong>{activeStudents}</strong>
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-icon orange">
              <BookOpen size={22} />
            </div>
            <div>
              <span>Courses</span>
              <strong>3</strong>
            </div>
          </div>
        </section>

        <section className="list-header">
          <div>
            <h3>All Students</h3>
            <p>View and manage your student records</p>
          </div>

          <div className="search-box">
            <Search size={18} />
            <input
              type="text"
              placeholder="Search students..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </section>

        {students.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">
              <Users size={34} />
            </div>
            <h3>No Students Found</h3>
            <p>There are currently no students in the system.</p>
          </div>
        ) : filteredStudents.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">
              <Search size={34} />
            </div>
            <h3>No Matching Students</h3>
            <p>Try searching with a different name or course.</p>
          </div>
        ) : (
          <div className="student-grid">
            {filteredStudents.map((student) => (
              <article className="student-card" key={student.id}>
                <div className="card-top">
                  <div className="avatar">
                    {student.name
                      .split(' ')
                      .map((word) => word[0])
                      .join('')}
                  </div>

                  {student.status === 'Active' ? (
                    <span className="status active">
                      <CheckCircle2 size={14} />
                      Active
                    </span>
                  ) : (
                    <span className="status inactive">
                      <XCircle size={14} />
                      Inactive
                    </span>
                  )}
                </div>

                <div className="student-info">
                  <h3>{student.name}</h3>
                  <p className="course">{student.course}</p>
                </div>

                <div className="details">
                  <div className="detail">
                    <Calendar size={17} />
                    <div>
                      <span>Age</span>
                      <strong>{student.age} years</strong>
                    </div>
                  </div>

                  <div className="detail">
                    <Mail size={17} />
                    <div>
                      <span>Email</span>
                      <strong>{student.email}</strong>
                    </div>
                  </div>
                </div>

                {student.status === 'Active' && (
                  <div className="active-message">
                    <CheckCircle2 size={16} />
                    Student is currently active.
                  </div>
                )}

                <button className="details-btn">
                  View Details
                  <ArrowRight size={17} />
                </button>
              </article>
            ))}
          </div>
        )}
      </main>

      <footer>
        <p>StudentHub • Built with React</p>
      </footer>
    </div>
  );
}

export default App;
